package com.speedboost

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

object DownloadEngine {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    suspend fun download(
        url: String,
        destination: File,
        maxBytesPerSecond: Long = 0L, // 0 = بدون حد للسرعة
        onProgress: (downloaded: Long, total: Long, speedKiB: Double) -> Unit
    ): File = withContext(Dispatchers.IO) {
        require(url.startsWith("https://")) { "استخدم رابط HTTPS صالحاً" }

        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "SpeedBoost/1.0")
            .build()

        client.newCall(request).execute().use { response ->
            check(response.isSuccessful) { "خطأ HTTP: ${response.code}" }
            val body = response.body ?: error("استجابة فارغة")
            val total = body.contentLength()
            destination.parentFile?.mkdirs()

            var downloaded = 0L
            val start = System.nanoTime()

            body.byteStream().use { input ->
                destination.outputStream().buffered().use { output ->
                    val buffer = ByteArray(16 * 1024)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break

                        output.write(buffer, 0, count)
                        downloaded += count

                        if (maxBytesPerSecond > 0) {
                            val elapsed = (System.nanoTime() - start) / 1_000_000_000.0
                            val targetSeconds = downloaded.toDouble() / maxBytesPerSecond
                            val waitMs = ((targetSeconds - elapsed) * 1000).toLong()
                            if (waitMs > 0) Thread.sleep(waitMs)
                        }

                        val actual = (System.nanoTime() - start) / 1_000_000_000.0
                        val speed = if (actual > 0) downloaded / actual / 1024.0 else 0.0
                        onProgress(downloaded, total, speed)
                    }
                }
            }
            destination
        }
    }
}
