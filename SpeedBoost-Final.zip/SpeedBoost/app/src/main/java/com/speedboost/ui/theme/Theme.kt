package com.speedboost.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SpeedBoostColors = darkColorScheme(
    primary = Color(0xFF00D9FF),
    secondary = Color(0xFF00E676),
    background = Color(0xFF10141C),
    surface = Color(0xFF1A2230),
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White,
    error = Color(0xFFFF5252)
)

@Composable
fun SpeedBoostTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SpeedBoostColors,
        content = content
    )
}
