package com.speedboost

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.speedboost.ui.theme.SpeedBoostTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SpeedBoostTheme { SpeedBoostScreen() } }
    }
}

@Composable
private fun SpeedBoostScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    var status by remember { mutableStateOf("جاهز") }
    var speed by remember { mutableStateOf("0.00 كيلوبايت/ث") }
    var shizukuStatus by remember { mutableStateOf("جارٍ التحقق") }
    var diagnostics by remember { mutableStateOf("لا توجد بيانات تشخيص بعد") }
    var url by remember { mutableStateOf("") }
    var progress by remember { mutableFloatStateOf(0f) }
    var busy by remember { mutableStateOf(false) }

    fun refreshShizuku() {
        shizukuStatus = when {
            !ShizukuManager.isAvailable() -> "Shizuku غير متصل"
            !ShizukuManager.hasPermission() -> "الإذن مطلوب"
            else -> "متصل"
        }
    }

    LaunchedEffect(Unit) { refreshShizuku() }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(20.dp))
                Text("معزز السرعة", style = MaterialTheme.typography.headlineLarge)
                Text("مراقبة الشبكة وإدارة التحميل", color = MaterialTheme.colorScheme.secondary)
                Spacer(Modifier.height(24.dp))

                Card(Modifier.fillMaxWidth()) {
                    Column(
                        Modifier.padding(24.dp).fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("سرعة التحميل", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        Text(speed, style = MaterialTheme.typography.headlineMedium)
                        Text("الحالة: $status")
                    }
                }

                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = {
                        scope.launch {
                            busy = true
                            try {
                                if (!ShizukuManager.isAvailable()) {
                                    status = "شغّل خدمة Shizuku أولاً"
                                } else if (!ShizukuManager.hasPermission()) {
                                    ShizukuManager.requestPermission()
                                    status = "امنح التطبيق إذن Shizuku ثم حدّث الحالة"
                                } else {
                                    diagnostics = NetworkOptimizer.inspectNetwork()
                                    status = "اكتمل فحص الشبكة"
                                }
                            } catch (e: Exception) {
                                status = e.message ?: "تعذر فحص الشبكة"
                            } finally {
                                busy = false
                                refreshShizuku()
                            }
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text("تحسين الشبكة / فحص الإعدادات") }

                OutlinedButton(
                    onClick = {
                        scope.launch {
                            busy = true
                            status = "جارٍ اختبار السرعة..."
                            try {
                                val measured = withContext(Dispatchers.IO) {
                                    val client = OkHttpClient.Builder()
                                        .callTimeout(90, TimeUnit.SECONDS)
                                        .build()
                                    val request = Request.Builder()
                                        .url("https://speed.cloudflare.com/__down?bytes=5000000")
                                        .build()
                                    client.newCall(request).execute().use { response ->
                                        check(response.isSuccessful) { "خطأ HTTP: ${response.code}" }
                                        val input = response.body?.byteStream()
                                            ?: error("استجابة فارغة")
                                        val start = System.nanoTime()
                                        var bytes = 0L
                                        input.use {
                                            val buffer = ByteArray(16 * 1024)
                                            while (true) {
                                                val n = it.read(buffer)
                                                if (n < 0) break
                                                bytes += n
                                            }
                                        }
                                        val seconds = (System.nanoTime() - start) / 1e9
                                        check(seconds > 0) { "تعذر قياس السرعة" }
                                        bytes / seconds / 1024.0
                                    }
                                }
                                speed = "%.2f كيلوبايت/ث".format(measured)
                                status = "اكتمل اختبار السرعة"
                            } catch (e: Exception) {
                                status = e.message ?: "فشل اختبار السرعة"
                            } finally {
                                busy = false
                            }
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("اختبار سرعة الإنترنت") }

                Spacer(Modifier.height(24.dp))
                HorizontalDivider()
                Spacer(Modifier.height(16.dp))
                Text("مدير التحميل", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("رابط الملف (HTTPS)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        scope.launch {
                            busy = true
                            progress = 0f
                            status = "جارٍ التحميل..."
                            try {
                                val baseDir = context.getExternalFilesDir(null) ?: context.filesDir
                                val file = File(baseDir, "downloads/${System.currentTimeMillis()}.bin")
                                DownloadEngine.download(url, file) { downloaded, total, currentSpeed ->
                                    speed = "%.2f كيلوبايت/ث".format(currentSpeed)
                                    if (total > 0) progress =
                                        (downloaded.toFloat() / total).coerceIn(0f, 1f)
                                }
                                progress = 1f
                                status = "اكتمل التحميل: ${file.name}"
                            } catch (e: Exception) {
                                status = e.message ?: "فشل التحميل"
                            } finally {
                                busy = false
                            }
                        }
                    },
                    enabled = !busy && url.startsWith("https://"),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("بدء التحميل") }

                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                Text("${(progress * 100).toInt()}%")

                Spacer(Modifier.height(20.dp))
                HorizontalDivider()
                Spacer(Modifier.height(12.dp))
                Text("حالة Shizuku: $shizukuStatus")
                TextButton(onClick = { refreshShizuku() }) { Text("تحديث حالة Shizuku") }
                Text("تشخيص الشبكة", style = MaterialTheme.typography.titleMedium)
                SelectionContainer {
                    Text(diagnostics, style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(20.dp))
                Text("معزز السرعة — الإصدار 1.0", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
