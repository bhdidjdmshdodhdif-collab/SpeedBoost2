package com.speedboost

object NetworkOptimizer {
    suspend fun inspectNetwork(): String {
        val command = """
            echo '=== هوية العملية ==='
            id
            echo '=== وضع DNS الخاص ==='
            settings get global private_dns_mode
            echo '=== اسم مضيف DNS الخاص ==='
            settings get global private_dns_specifier
            echo '=== خوادم DNS المرئية ==='
            getprop net.dns1
            getprop net.dns2
            echo '=== TCP SACK ==='
            cat /proc/sys/net/ipv4/tcp_sack 2>/dev/null || echo غير متاح
            echo '=== TCP timestamps ==='
            cat /proc/sys/net/ipv4/tcp_timestamps 2>/dev/null || echo غير متاح
            echo '=== TCP window scaling ==='
            cat /proc/sys/net/ipv4/tcp_window_scaling 2>/dev/null || echo غير متاح
        """.trimIndent()
        return ShizukuManager.execute(command)
    }
}
