package com.speedboost

import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.lang.reflect.InvocationTargetException

object ShizukuManager {
    private const val REQUEST_CODE = 1001

    fun isAvailable(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        isAvailable() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun requestPermission() {
        if (isAvailable() && !hasPermission()) {
            Shizuku.requestPermission(REQUEST_CODE)
        }
    }

    /**
     * Shizuku.newProcess أصبحت private في الإصدارات الحديثة من واجهة Shizuku،
     * لذلك تُستدعى بالـ reflection (يعمل سواء كانت public أو private).
     */
    private fun newShizukuProcess(command: Array<String>): Process {
        val method = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        method.isAccessible = true
        try {
            return method.invoke(null, command, null, null) as Process
        } catch (e: InvocationTargetException) {
            throw e.targetException ?: e
        }
    }

    suspend fun execute(command: String): String = withContext(Dispatchers.IO) {
        check(isAvailable()) { "خدمة Shizuku غير متاحة" }
        check(hasPermission()) { "لم يتم منح إذن Shizuku" }

        val process = newShizukuProcess(arrayOf("sh", "-c", command))
        try {
            val stdout = process.inputStream.bufferedReader().readText()
            val stderr = process.errorStream.bufferedReader().readText()
            val exitCode = process.waitFor()
            check(exitCode == 0) {
                stderr.ifBlank { stdout }.ifBlank { "فشل تنفيذ الأمر (رمز $exitCode)" }
            }
            stdout.ifBlank { "تم تنفيذ الأمر." }
        } finally {
            process.destroy()
        }
    }
}
