# SpeedBoost — معزز السرعة

مشروع Android بلغة Kotlin وواجهة Jetpack Compose عربية RTL.

## البناء على GitHub (من ملف ZIP واحد)
1. أنشئ مستودعاً جديداً على GitHub.
2. مرة واحدة فقط: من المستودع اختر **Add file → Create new file**، اكتب الاسم
   `.github/workflows/build-apk.yml` والصق محتوى الملف `build-apk.yml` المرفق، ثم Commit.
3. ارفع ملف `SpeedBoost-Final.zip` كما هو (**Add file → Upload files**) إلى جذر المستودع ثم Commit.
4. يبدأ البناء تلقائياً (أو شغّله من **Actions → Build SpeedBoost APK → Run workflow**).
5. بعد النجاح افتح الـ Run وحمّل **SpeedBoost-debug-apk** من قسم **Artifacts**
   (ملف مضغوط بداخله `SpeedBoost-debug.apk`).

> يعمل Workflow أيضاً إذا فككت المشروع ورفعت ملفاته مباشرة إلى جذر المستودع.

## البناء محلياً
يتطلب JDK 17 وAndroid SDK وGradle 8.9+:
```bash
gradle assembleDebug
```
الناتج: `app/build/outputs/apk/debug/app-debug.apk`

## ملاحظات
- يتطلب استخدام واجهة Shizuku تثبيت تطبيق Shizuku وتشغيل خدمته ومنح الإذن للتطبيق.
- فحص إعدادات النظام تشخيصي فقط؛ صلاحية Shizuku لا تعني صلاحية root ولا تضمن تعديل خصائص kernel.
- محرك التحميل يستخدم طلب HTTP واحداً مع حد سرعة اختياري (معطّل افتراضياً)، ولا يتجاوز قيود الخادم أو الشبكة.
- اختبار السرعة يقيس تنزيل عينة صغيرة من Cloudflare؛ النتيجة تتأثر بالخادم والاتصال.
- APK الناتج موقّع بمفتاح debug ومناسب للتجربة والتثبيت اليدوي فقط.
